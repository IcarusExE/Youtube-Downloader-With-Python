from pytube import YouTube
import pyfiglet
import os
ascii_banner = pyfiglet.figlet_format("Venta YT Downloader")
print(ascii_banner)

link = input("--> ")
os.system('cls')
ascii_banner = pyfiglet.figlet_format("Venta YT Downloader")
print(ascii_banner)
print("Yükleniyor")
youtube = YouTube(link)
os.system('cls')
ascii_banner = pyfiglet.figlet_format("Venta YT Downloader")
print(ascii_banner)
print("Yükleniyor...")
stream = youtube.streams.get_highest_resolution()
stream.download()


print("Yüklendi")
input("Enter'a basarak Programı Kapatabilirsin. ")

#By venta